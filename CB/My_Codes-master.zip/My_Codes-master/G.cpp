#include <bits/stdc++.h>
#define  pb          push_back
#define  f           first
#define  s           second
#define  pi          acos(-1.0)
#define  LCM(a,b)    a*b/__gcd(a,b)
#define  GCD(a,b)    __gcd(a,b)
#define  sof         sizeof
#define  endl        '\n'
#define  eps         1e-6
typedef long long ll;
using namespace std;

const int mod = 1e9 + 7;
const int N = 2e5 + 6;


int n;
int a[N];
int cycle[N];
int Parent[N], Rank[N];

void Init(int n)
{
    for (int i = 1 ; i <= n ; i++)
        Rank[i] = 1, Parent[i] = i, cycle[i] = 0;
}

int Find_Parent(int v)
{
    if (v == Parent[v])
        return v;

    return Parent[v] = Find_Parent(Parent[v]);
}

void Union(int a, int b)
{
    a = Find_Parent(a);
    b = Find_Parent(b);

    if (a != b)
    {

        if (Rank[a] > Rank[b])
            swap (a, b);

        Parent[a] = b;
        Rank[b] += Rank[a];
    }
    else
        cycle[a] = 1;
}

void Solve()
{

    cin >> n;
    map<pair<int, int>, int> mp;

    for (int i = 1 ; i <= n ; i++)
        cin >> a[i];

    Init(n);

    for (int i = 1 ; i <= n ; i++)
    {
        if (mp[ {i, a[i]}] || mp[ {a[i], i}])
            continue;
        Union(i, a[i]);
        mp[ {i, a[i]}] = 1;
        mp[ {a[i], i}] = 1;
    }

    // for (int i = 1 ; i <= n ; i++)
    //     cout << i << " " << Find_Parent(i) << endl;

    int tot = 0;
    set<int>st;
    for (int i = 1 ; i <= n ; i++)
        st.insert(Find_Parent(i));

    for (auto i : st)
        tot += cycle[i];

    cout << tot + (tot != (int) st.size()) << " " << st.size() << endl;

}

int main()
{

    ios::sync_with_stdio(false);
    cin.tie(0);

    int tt = 1;

    cin >> tt;

    while (tt--)
    {

        Solve();
    }

    return 0;

}