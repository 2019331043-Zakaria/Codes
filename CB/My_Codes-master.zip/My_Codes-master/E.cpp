#include <bits/stdc++.h>
#define  pb          push_back
#define  f           first
#define  s           second
#define  pi          acos(-1.0)
#define  LCM(a,b)    a*b/__gcd(a,b)
#define  GCD(a,b)    __gcd(a,b)
#define  sof         sizeof
#define  endl        '\n'
#define  eps         1e-6
typedef long long ll;
using namespace std;

const int mod = 1e9 + 7;
const int N = 2e5 + 6;

int a[N][25];

struct  {
        ll prop, sum;
} tree[N * 4][25];

void init(int node, int b, int e, int Bit)
{
        if (b == e) {
                tree[node][Bit].sum = a[b][Bit];
                return;
        }

        int Left = node * 2;
        int Right = node * 2 + 1;

        int mid = (b + e) >> 1;

        init(Left, b, mid, Bit);
        init(Right, mid + 1, e, Bit);

        tree[node][Bit].sum = tree[Left][Bit].sum + tree[Right][Bit].sum;
}

void update(int node, int b, int e, int i, int j, ll x, int Bit)
{
        if (i > e || j < b)
                return ;
        if (b >= i && e <= j)
        {
                tree[node][Bit].sum += ((e - b + 1) * x);
                tree[node][Bit].prop += x;
                return;
        }
        int Left = node * 2;
        int Right = (node * 2) + 1;
        int mid = (b + e) / 2;

        update(Left, b, mid, i, j, x, Bit);
        update(Right, mid + 1, e, i, j, x, Bit);

        tree[node][Bit].sum = tree[Left][Bit].sum + tree[Right][Bit].sum + (e - b + 1) * tree[node][Bit].prop;

}

ll query(int node, int b, int e, int i, int j,  int Bit, ll carry = 0)
{
        if (i > e || j < b)
                return 0;

        if (b >= i and e <= j)
                return tree[node][Bit].sum + carry * (e - b + 1);

        int Left = node << 1;
        int Right = (node << 1) + 1;
        int mid = (b + e) >> 1;

        ll p1 = query(Left, b, mid, i, j, Bit,  carry + tree[node][Bit].prop);
        ll p2 = query(Right, mid + 1, e, i, j, Bit,  carry + tree[node][Bit].prop);

        return p1 + p2;
}

void Solve()
{



}

int main()
{

        ios::sync_with_stdio(false);
        cin.tie(0);

        int tt = 1;

        cin >> tt;

        while (tt--)
        {

                Solve();
        }

        return 0;

}