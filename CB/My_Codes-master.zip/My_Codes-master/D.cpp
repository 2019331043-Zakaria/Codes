#include<bits/stdc++.h>
using namespace std;

#define pb push_back
#define fi first
#define se second
#define mk make_pair
#define endl "\n"
#define enld "\n"
#define fastio {ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);}

#define For(i, n, m) for(ll (i)=(m);(i)<(n);++(i))
#define rep(i, n) For(i,n,0)

#define  LCM(a,b)    a*b/__gcd(a,b)
#define  GCD(a,b)    __gcd(a,b)

#define sz 100010
#define mod 1000000007
#define inf 100000000000000ll

typedef long long int ll;
typedef pair<ll, ll>  pl;

struct segmentTree
{
    ll n;
    vector<ll> v, tree, lazy;

    segmentTree(ll n, vector<ll> v)
    {
        this->v = v;
        this-> n = n;
        tree.resize(4 * n);
        lazy.resize(4 * n);
        build();
    }

    ll update(ll node , ll tl, ll tr, ll ql , ll qr, ll x);
    ll query(ll node , ll tl, ll tr, ll ql , ll qr, ll x);
    void build();
};

ll segmentTree::update(ll node, ll tl, ll tr, ll ql , ll qr, ll x)
{
    if (tr < tl) return 0;
    if (qr < tl || tr < ql) return 0;

    if (ql <= tl && tr <= qr)
    {
        lazy[node] ^= x;
        if(lazy[node])
        {
            
        }
        return (tr - tl + 1) * x;
    }

    ll mid = (tl + tr) / 2;

    ll left = update(2 * node + 1, tl , mid, ql, qr, x);
    ll right = update(2 * node + 2, mid + 1, tr, ql, qr, x);

    tree[node] += left + right;

    return left + right;
}

ll segmentTree::query(ll node, ll tl, ll tr, ll ql , ll qr, ll x)
{
    if (tr < tl) return 0;
    
    lazy[node] += x;
    
    if (qr < tl || tr < ql) return 0;

    if (ql <= tl && tr <= qr)
    {
        return tree[node] + (tr - tl + 1) * lazy[node];
    }

    ll mid = (tl + tr) / 2;

    ll left = query(2 * node + 1, tl , mid, ql, qr, lazy[node]);
    ll right = query(2 * node + 2, mid + 1, tr, ql, qr, lazy[node]);

    tree[node] += (tr - tl + 1) * lazy[node];
    lazy[node] = 0;

    return left + right;
}


void segmentTree::build()
{
    for (int i = 0; i < n; i++)
    {
        update(0, 0, n - 1, i, i, v[i]);
    }
}

void solve()
{
    ll n, q;
    cin >> n >> q;
    vector<ll> v(n);
    for(int i=0 ; i<n ; i++)
        cin>>v[i];

    segmentTree st[23];
    st[1](v, n);

    while (q--)
    {
        ll type, l, r;
        cin >> type >> l >> r;
        cout<<type<<" "<<l<<" "<<r<<endl;

        l--, r--;
        // cout << "-------" << endl;
        if (type == 0)
        {
            ll val;
            cin >> val;
            
            st.update(0, 0, n - 1, l, r, val);
        }
        else
        {
            // cout << l << " " << r << endl;
            cout << st.query(0, 0, n - 1, l, r, 0) << endl;
        }
    }
}

int main()
{
    fastio
    int t = 1;
    cin >> t;
    while (t--)solve();
}