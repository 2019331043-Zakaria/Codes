#include <bits/stdc++.h>
#define endl "\n"
using namespace std;
typedef long long int ll;
int main()
{
    int n;
    cin>>n;
    int a[n+1],b[n+1];
    for(int i=1;i<=n;i++)
        cin>>a[i];
    for(int i=1;i<=n;i++)
        cin>>b[i];
    vector<int>p,q;
    int cnt=0;
    for(int i=1;i<=n;i++)
    {
        cnt++;
        if(a[i]==1)
            break;
    }
    int cnt1=0;
    for(int i=1;i<=n;i++)
    {
        cnt1++;
        if(b[i]==1)
            break;
    }

   for(int i=cnt;i<=n;i++)
    p.push_back(a[i]);
   for(int i=1;i<cnt;i++)
    p.push_back(a[i]);
   for(int i=cnt1;i<=n;i++)
    q.push_back(b[i]);
   for(int i=1;i<cnt1;i++)
    q.push_back(b[i]);

     int ans=0;
   for(int i=0;i<n;i++)
    {
        if(p[i]==q[i])
          ans++;
    }

     cout<<ans<<endl;





return 0;
}
