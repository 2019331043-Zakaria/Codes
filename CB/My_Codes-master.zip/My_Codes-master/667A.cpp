#include <bits/stdc++.h>
#define  pb          push_back
#define  f           first
#define  s           second
#define  pi          acos(-1.0)
#define  LCM(a,b)    a*b/__gcd(a,b)
#define  GCD(a,b)    __gcd(a,b)
#define  mod         1000000007
#define  sof         sizeof
#define  endl        '\n'
#define  MAX         5000002
typedef long long ll;
using namespace std;


void Solve()
{
       
       
       

       
}
int main()
{
     
      ios::sync_with_stdio(false);
      cin.tie(0);
    
     
      int tt=1;
      cin>>tt;
      while(tt--)
      {
           
            Solve();
      }

      return 0;


}