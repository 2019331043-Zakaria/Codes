/*
* @Author: Zakaria 
* @Date:   2022-04-01 01:08:32
* @Last Modified time: 2022-08-22 19:32:45
*/
#include <bits/stdc++.h>
#define  pb          push_back
#define  f           first
#define  s           second
#define  pi          acos(-1.0)
#define  LCM(a,b)    a*b/__gcd(a,b)
#define  GCD(a,b)    __gcd(a,b)
#define  sof         sizeof
#define  endl        '\n'
#define  MAX         200002
typedef long long  ll;
using namespace std;

int n;
string s;
int x, y;
int curx, cury;

void add(char c)
{
             if(c=='U')
                cury++;
             if(c=='D')
                cury--;
             if(c=='R')
                curx++;
             if(c=='L')
                curx--;
}
void sub(char c)
{
             if(c=='U')
                cury--;
             if(c=='D')
                cury++;
             if(c=='R')
                curx--;
             if(c=='L')
                curx++;
}

bool check(int len)
{
         curx=0, cury=0;
        
        for(int i=len ; i<=n ; i++)
        {
             add(s[i]);
        } 

       
        for(int i = len ; i<=n ; i++)
        {
             sub(s[i]);
             add(s[i-len]);

           
             ll bakix = abs(x - curx);
             ll bakiy = abs(y - cury);

             ll temp=len;
             temp-=bakix;
             temp-=bakiy;

             if(temp<0)
                continue;

             if(temp%2==0)
               return 1;
        }

        return 0; 



}
void Solve()
{
      
          cin>>n;
          cin>>s;
          cin>>x>>y;
          
          s='*'+s;


          int low=0, high=n;
          int ans=n+1;

          while(low<=high)
          {
              int mid=(low+high)/2;
              if(check(mid))
                high=mid-1, ans=mid;
              else
                low=mid+1;
          }

          if(ans==n+1)
            cout<<-1<<endl;
          else
            cout<<ans<<endl;
          
} 
 
int main()
{
         
        ios::sync_with_stdio(false);
        cin.tie(0);
        
        int tt=1;
        
        //cin>>tt;
        
        while(tt--)
        {
           
            Solve();
        }
 
        return 0;
        
} 