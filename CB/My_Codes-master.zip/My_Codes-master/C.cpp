#include <bits/stdc++.h>
#define  pb          push_back
#define  f           first
#define  s           second
#define  pi          acos(-1.0)
#define  LCM(a,b)    a*b/__gcd(a,b)
#define  GCD(a,b)    __gcd(a,b)
#define  sof         sizeof
#define  endl        '\n'
#define  eps         1e-6
typedef long long ll;
using namespace std;

const int mod = 1e9 + 7;
const int N = 2e5 + 6;

bool ok(vector<string>v)
{
   

    for(int i=1 ; i<v.size() ; i++)
    {
        string prev = v[i-1];
        string cur = v[i];
    //    cout<<prev<<" "<<cur<<endl;
        int cnt = 0;
        for(int k = 0 ; k<prev.size() ; k++)
            cnt+=(prev[k]!=cur[k]);

        if(cnt!=1)
            return 0;
    }

    return 1;
}
void Solve()
{

    int n, m;
    cin >> n >> m;
    string s[n+1];
    for(int i=1 ; i<=n ; i++) cin>>s[i];
    vector<int>v;

    for (int i = 1 ; i <= n ; i++)
        v.push_back(i);

    do{

        vector<string>bal;

        for(auto i:v)
            bal.push_back(s[i]);

        if(ok(bal))
        {
            cout<<"Yes"<<endl;
            return ;
        }
    }while(next_permutation(v.begin(), v.end()));

    cout<<"No"<<endl;
}

int main()
{

    ios::sync_with_stdio(false);
    cin.tie(0);

    int tt = 1;

    //    cin>>tt;

    while (tt--)
    {

        Solve();
    }

    return 0;

}