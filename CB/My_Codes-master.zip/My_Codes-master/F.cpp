#include <bits/stdc++.h>
#define  pb          push_back
#define  f           first
#define  s           second
#define  pi          acos(-1.0)
#define  LCM(a,b)    a*b/__gcd(a,b)
#define  GCD(a,b)    __gcd(a,b)
#define  sof         sizeof
#define  endl        '\n'
#define  eps         1e-6
typedef long long ll;
using namespace std;

const int mod = 1e9 + 7;
const int N = 2e5 + 6;
ll bigmod(ll a, ll b, ll n)
{
	ll res = 1;
	if (b == 0)
		return 1;
	a = a % n;
	if (a == 0)
		return 0;
	while (b > 0)
	{

		if (b % 2)
			res = (res * a) % n;
		b = b / 2;
		a = (a * a) % n;
	}
	return res;
}

void Solve()
{

	int n, m;
	cin >> n >> m;

	int a[n];
	for (int i = 0 ; i < n ; i++)
		cin >> a[i];

	sort(a, a + n);



	map<ll, ll>freq;
	set<ll>st;
	for (int i = 0 ; i < n ; i++)
		freq[a[i]]++, st.insert(a[i]);

	vector<int>v;

	for (auto i : st)
		v.push_back(i);

	ll mul[n + 1];
	mul[(int) st.size()] = 1;

	for (int i = st.size() - 1 ; i >= 0 ; i--)
	{
		mul[i] = mul[i + 1] * freq[v[i]];
		mul[i] %= mod;
	}

	ll ans = 0;
	// for (auto i : a)
	// 	cout << i << " ";
	// cout << endl;

	// for (auto i : v)
	// 	cout << i << " ";
	// cout << endl;

	for (int i = v.size() - m ; i >= 0 ; i--)
	{
		ll id = i + m - 1 ;
		if (v[id] - v[i] >= m)
			continue;

		ll inv = bigmod(mul[id + 1], mod - 2, mod);

		inv *= mul[i];
		inv %= mod;

		ans += inv;
		ans %= mod;
	}

	cout << ans << endl;





}

int main()
{

	ios::sync_with_stdio(false);
	cin.tie(0);

	int tt = 1;

	cin >> tt;

	while (tt--)
	{

		Solve();
	}

	return 0;

}