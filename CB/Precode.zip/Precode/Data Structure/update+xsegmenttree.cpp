ll a[MAX];
struct 
{
    ll prop=-1, sum;
} tree[MAX * 4];

void init(int node, int b, int e)
{
    if (b == e) {
        tree[node].sum = a[b];
        tree[node].prop=-1;

        return;
    }
    int Left = node * 2;
    int Right = node * 2 + 1;
    int mid = (b + e) / 2;
    init(Left, b, mid);
    init(Right, mid + 1, e);
    tree[node].sum = tree[Left].sum + tree[Right].sum;
    tree[node].prop=-1;
}

void update(int node, int b, int e, int i, int j, ll x)
{
    if (i > e || j < b)
        return;
    if (b >= i && e <= j) 
    {
        tree[node].sum = ((e - b + 1) * x);
        tree[node].prop = x; 
        return;
    }
 
    int Left = node * 2;
    int Right = (node * 2) + 1;
    int mid = (b + e) / 2;
    
    if(tree[node].prop != -1)
    { 
       tree[Left].prop = tree[Right].prop = tree[node].prop;

       tree[Left].sum = (mid-b+1) * tree[node].prop;
       
       tree[Right].sum = (e-mid)*tree[node].prop; 
       
       tree[node].prop = -1;
    }


    update(Left, b, mid, i, j, x);
    update(Right, mid + 1, e, i, j, x);
    tree[node].sum = tree[Left].sum + tree[Right].sum;
}

ll query(int node, int b, int e, int i, int j, ll carry = 0)
{
    if (i > e || j < b)
        return 0;

    if (b >= i and e <= j)
        return tree[node].sum ;

    int Left = node << 1;
    int Right = (node << 1) + 1;
    int mid = (b + e) >> 1;

     if(tree[node].prop != -1)
    { 
       tree[Left].prop = tree[Right].prop = tree[node].prop;

       tree[Left].sum = (mid-b+1) * tree[node].prop;
       
       tree[Right].sum = (e-mid)*tree[node].prop; 
       
       tree[node].prop = -1;
    }


    ll p1 = query(Left, b, mid, i, j);
    ll p2 = query(Right, mid + 1, e, i, j);

    return p1 + p2;
}
