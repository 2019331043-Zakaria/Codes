const int N = 2e5 + 9;
int Table[N][20], a[N];
void Build(int n)
{
    for (int i = 1 ; i <= n ; i++)
        Table[i][0] = a[i];
    for (int k = 1 ; k < 20 ; k++)
    {
        for (int i = 1 ; i + (1 << k) - 1 <= n ; i++)
            Table[i][k] = min(Table[i][k - 1], Table[i + (1 << (k - 1))][k - 1]);
    }
}
int Query(int l, int r)
{
    int k = log2(r - l + 1);
    return min(Table[l][k], Table[r - (1 << k) + 1][k]);
}