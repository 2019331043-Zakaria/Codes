int n,m;
int Parent[N], Rank[N];

void Init(int n)
{
          for(int i=1 ; i<=n ; i++)
            Rank[i]=1, Parent[i]=i;
}

int Find_Parent(int v)
{
    if (v == Parent[v]) 
        return v;

    return Parent[v] = Find_Parent(Parent[v]);
}
 
void Union(int a, int b)
{
    a = Find_Parent(a);
    b = Find_Parent(b);
    
    if (a != b) 
    {

        if (Rank[a] > Rank[b]) 
            swap (a, b);
                
        Parent[a] = b;
        Rank[b] += Rank[a];
    }
}
